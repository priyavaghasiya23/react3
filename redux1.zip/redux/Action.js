export const myAction = (payload) => ({
    type: "ADD",
    payload
});


export const deleteAction = (index) => ({
    type: "DELETE",
    payload: index
});


export const editAction = (index) => ({
    type: "edit",
    payload: index
});
