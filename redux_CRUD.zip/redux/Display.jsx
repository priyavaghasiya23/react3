import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { deleteAction, editAction } from './Action'

export default function Display() {
    const data = useSelector(store => store)
    const dispatch = useDispatch()

    return (
        <div>
            {data.map((el, i) => (
                <div key={i}>
                    Name: {el.name}
                    <button onClick={() => dispatch(deleteAction(i))}>Delete</button>
                    <button onClick={() => dispatch(editAction(i))}>Edit</button>
                </div>
            ))}
        </div>
    )
}






