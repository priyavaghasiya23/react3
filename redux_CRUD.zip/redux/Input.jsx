import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { myAction } from './Action'

export default function Input() {
    const [name, setName] = useState("")
    const dispatch = useDispatch()

    const handleSubmit = (e) => {
        e.preventDefault()
        if (name) {
            dispatch(myAction({name}))
            setName("")
           
        }
    }

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" value={name} placeholder="Name" onChange={(e) => setName(e.target.value)} />
            <button type="submit">Add</button>
        </form>
    )
}