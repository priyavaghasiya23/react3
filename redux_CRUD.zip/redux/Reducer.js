const arr = [];

export const myReducer = (state = arr, action) => {
    if (action.type === "ADD") {
        return [...state, action.payload];
    }

    if (action.type === "DELETE") {
        const newData = [...state];
        newData.splice(action.payload, 1);
        return newData;
    }

    if (action.type === "edit") {
        const newName = prompt("Edit name", state[action.payload].name);
        const newData = [...state];
        newData[action.payload] = {
            ...newData[action.payload],
            name: newName,
        };
        return newData;
    }

    return state;
};